Module H5I
==========

.. automodule:: h5py.h5i
    :members:


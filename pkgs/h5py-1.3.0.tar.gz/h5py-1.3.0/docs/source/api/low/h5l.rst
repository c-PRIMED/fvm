Module H5L
==========

This module is only available when compiled against HDF5 1.8.0 and higher.

.. automodule:: h5py.h5l
    :members:

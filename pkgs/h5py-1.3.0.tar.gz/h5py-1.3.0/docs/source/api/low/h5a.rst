Module H5A
==========

.. automodule:: h5py.h5a
    :members:

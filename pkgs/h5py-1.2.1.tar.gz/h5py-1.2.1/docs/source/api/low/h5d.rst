Module H5D
==========

.. automodule:: h5py.h5d
    :members:

#!/usr/bin/env python
#
# Created by: Pearu Peterson, October 2003
#

from numpy.testing import *

import scipy.linalg.atlas_version


# No futher tests possible.
# Importing atlas_version will print out atlas version.

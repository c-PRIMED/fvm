
# Modules contributed by BasSw (wegwerp@gmail.com)
from codata import *
from constants import *

major = 0
minor = 4
micro = 3


fftpack_version = '%(major)d.%(minor)d.%(micro)d' % (locals ())

==========================================
Miscellaneous routines (:mod:`scipy.misc`)
==========================================

.. warning::

   This documentation is work-in-progress and unorganized.

.. automodule:: scipy.misc
   :members:

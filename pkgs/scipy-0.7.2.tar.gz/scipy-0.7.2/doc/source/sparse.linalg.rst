==================================================
Sparse linear algebra (:mod:`scipy.sparse.linalg`)
==================================================

.. warning::

   This documentation is work-in-progress and unorganized.

.. automodule:: scipy.sparse.linalg
   :members:

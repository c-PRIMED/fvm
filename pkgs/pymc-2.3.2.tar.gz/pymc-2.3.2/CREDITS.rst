************
PyMC Credits
************

Development team
================

* Christopher Fonnesbeck
* David Huard
* Anand Patil
* John Salvatier

Contributors
============

* Andrew Straw : the Von Mises distribution and code to strip trailing whitespace.
* Max Nickel : A bugfix in the Raftery-Lewis convergence diagnostic
* Joonas Paalasmaa : Fixed an installation bug
* Nicholas Matsakis : Changed typographer's quotes to straight quotes in documentation
* Nick Ward : Fixed breaking behaviour for Python 3


# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.11.0rc2'
version = '0.11.0rc2'
full_version = '0.11.0rc2'
git_revision = 'ffd7eba9d230f7008d73e22904d37862c91ff5c7'
release = True

if not release:
    version = full_version

def test_normal():
    pass

def test_gosper():
    pass

"""Used for translating a string into a sympy expression.
"""

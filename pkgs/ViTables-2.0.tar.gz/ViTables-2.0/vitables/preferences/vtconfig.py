# -*- coding: utf-8 -*-
#!/usr/bin/env python


########################################################################
#
#       Copyright (C) 2005, 2006, 2007 Carabos Coop. V. All rights reserved
#       Copyright (C) 2008 Vicent Mas. All rights reserved
#
#       This program is free software: you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation, either version 3 of the License, or
#       (at your option) any later version.
#
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#
#       You should have received a copy of the GNU General Public License
#       along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#       Author:  Vicent Mas - vmas@vitables.org
#
#       $Source$
#       $Id: vtconfig.py 1071 2008-10-17 16:49:03Z vmas $
#
########################################################################

"""
Here is defined the Config class.

Classes:

* Config(QtCore.QSettings)

Methods:

* __init__(self)
* readStartupWorkingDir(self)
* readStyle(self)
* readValue(self, key)
* writeValue(self, key, value)

Functions:

* getVersion()

Misc variables:

* __docformat__


Every access to the config settings is done via a
`QSettings` instance that, in turn, will access the config file and return the
read setting to the application. Saving settings works in a similar way,
the application passes the setting to the `QSetting` instance and it (the
instance) will write the setting into the config file.

About the config file location
------------------------------
If format is NativeFormat then the default search path will be:

- Unix

  - UserScope

    - ``$HOME/.config/MyCompany/ViTables.conf``
    - ``$HOME/.config/MyCompany.conf``

  - SystemScope

    - ``/etc/xdg/MyCompany/ViTables.conf``
    - ``/etc/xdg/MyCompany.conf``

- MacOSX

  - UserScope

    - ``$HOME/Library/Preferences/org.vitables.ViTables.plist``
    - ``$HOME/Library/Preferences/org.vitables.plist``

  - SystemScope

    - ``/Library/Preferences/org.vitables.ViTables.plist``
    - ``/Library/Preferences/org.vitables.plist``

- Windows

  - UserScope

    - ``HKEY_CURRENT_USER/Software/MyCompany/ViTables``
    - ``HKEY_CURRENT_USER/Software/MyCompany/``

  - SystemScope

    - ``HKEY_LOCAL_MACHINE/Software/MyCompany/ViTables``
    - ``HKEY_LOCAL_MACHINE/Software/MyCompany/``

If format is NativeFormat and platform is Unix the path can be set via
QtCore.QSettings.setPath static method.

About the config file name
--------------------------
If format is NativeFormat:

- under Unix, Product Name -> Product Name.conf so the product name
  ``ViTables`` will match a configuration file named ``ViTables.conf``
- under MacOSX, Internet Domain and Product Name ->
  reversed Internet Domain.Product Name.plist so the domain
  ``vitables.org`` and the product ``ViTables`` become
  ``org.vitables.ViTables.plist``

Before to read/write a property value we must provide the product
name as the first subkey of the property key.
This can be done in two different ways:

a)  including the product name every time we read/write settings, e.g.
    `readEntry(/ViTables/Logger/Font)`
b)  using `setPath` method once before we read/write settings, so
    the preceding example becomes `readEntry(/Logger/Font)`
"""

__docformat__ = 'restructuredtext'
__version__ = '2.0'

import os
import sys

import PyQt4.QtCore as QtCore
import PyQt4.QtGui as QtGui

from vitables.preferences import configException
import vitables.utils

def getVersion():
    """The application version."""
    return __version__



class Config(QtCore.QSettings):
    """
    Manages the application configuration dynamically.

    This class defines accessor methods that allow the application (a
    VTApp instance)to read the configuration file.
    The class also provides a method to save the current configuration
    in the configuration file.
    """

    def __init__(self):
        """
        Setup the application configurator.

        Set the following paths to the proper values:

        - translations directory
        - icons directory
        - documentation directory
        - configuration directory
        """

        # The scope is UserScope and the format is NativeFormat
        # System-wide settings will not be searched as a fallback
        QtCore.QSettings.__init__(self, 'ViTables')
        self.setFallbacksEnabled(False)

        # The default style depends on the platform
        if sys.platform.startswith('win'):
            # if VER_PLATFORM_WIN32_NT (i.e WindowsNT/2000/XP)
            if sys.getwindowsversion()[3] == 2:
                self.default_style = 'WindowsXP'
            else:
                self.default_style = 'Windows'
        elif sys.platform.startswith('darwin'):
            self.default_style = 'Macintosh (Aqua)'
        else:
            self.default_style = 'Motif'

        # The settings search path
        if sys.platform.startswith('win'):
            # On windows systems settings will be stored in the registry
            # under the Carabos key
            pyversion = 'Python%s%s' % (sys.version_info[0], sys.version_info[1])
            self.base_key = 'ViTables/%s/%s' % (__version__, pyversion)
        elif sys.platform.startswith('darwin'):
            # Mac OS X saves settings in a properties list stored in a
            # standard location, either on a global or user basis (see
            # docstring.for more information)
            # Setting the NativeFormat paths on MacOSX has no effect
            self.base_key = 'ViTables'
        else:
            # On Unix systems settings will be stored in a plain text
            # file (see the module docstring for name conventions)
            self.base_key = 'ViTables'
            config_directory = os.path.join(str(QtCore.QDir.homePath()),
                '.vitables')
            if not os.path.isdir(config_directory):
                os.mkdir(config_directory)
            self.setPath(QtCore.QSettings.NativeFormat,
                QtCore.QSettings.UserScope, config_directory)


    def loggerPaper(self):
        """
        Returns the logger background color.
        """

        key = 'Logger/Paper'
        default_value = QtCore.QVariant(QtGui.QColor("#ffffff"))
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.Color):
            return setting_value
        else:
            return default_value


    def loggerText(self):
        """
        Returns the logger text color.
        """

        key = 'Logger/Text'
        default_value = QtCore.QVariant(QtGui.QColor("#000000"))
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.Color):
            return setting_value
        else:
            return default_value


    def loggerFont(self):
        """
        Returns the logger font.
        """

        key = 'Logger/Font'
        default_value = QtCore.QVariant(QtGui.qApp.font())
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.Font):
            return setting_value
        else:
            return default_value


    def workspaceBackground(self):
        """
        Returns the workspace background color.
        """

        key = 'Workspace/Background'
        default_value = QtCore.QVariant(QtGui.QBrush(QtGui.QColor("#ffffff")))
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.Brush):
            return setting_value
        else:
            return default_value


    def readStyle(self):
        """Returns the current application style."""

        # The property key and its default value
        key = 'Look/currentStyle'
        default_value = QtCore.QVariant('default')

        # Read the entry from the configuration file/registry
        entry = self.value(key)

        # Check the entry format and value
        if not entry.canConvert(QtCore.QVariant.String):
            return default_value
        elif str(entry.toString()) not in ['default', 'Windows', 'Motif', 
                                        'MotifPlus', 'Platinum', 'SGI', 
                                        'CDE']:
            return default_value
        else:
            return entry


    def windowPosition(self):
        """
        Returns the main window geometry setting.
        """

        key = 'Geometry/Position'
        default_value = QtCore.QVariant()
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.ByteArray):
            return setting_value
        else:
            return default_value


    def windowLayout(self):
        """
        Returns the main window layout setting.

        This setting stores the position and size of toolbars and
        dockwidgets.
        """

        key = 'Geometry/Layout'
        default_value = QtCore.QVariant()
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.ByteArray):
            return setting_value
        else:
            return default_value


    def hsplitterPosition(self):
        """
        Returns the horizontal splitter geometry setting.
        """

        key = 'Geometry/HSplitter'
        default_value = QtCore.QVariant()
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.ByteArray):
            return setting_value
        else:
            return default_value


    def vsplitterPosition(self):
        """
        Returns the vertical splitter geometry setting.
        """

        key = 'Geometry/VSplitter'
        default_value = QtCore.QVariant()
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.ByteArray):
            return setting_value
        else:
            return default_value


    def startupLastSession(self):
        """
        Returns the restore last session setting.
        """

        key = 'Startup/restoreLastSession'
        default_value = QtCore.QVariant(False)
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.Bool):
            return setting_value
        else:
            return default_value


    def startupWorkingDir(self):
        """
        Returns the startup working directory setting.
        """

        key = 'Startup/startupWorkingDir'
        default_value = QtCore.QVariant('home')
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.String):
            return setting_value
        else:
            return default_value


    def lastWorkingDir(self):
        """
        Returns the last working directory setting.
        """

        key = 'Startup/lastWorkingDir'
        default_value = QtCore.QVariant(vitables.utils.getHomeDir())
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.String):
            return setting_value
        else:
            return default_value


    def recentFiles(self):
        """
        Returns the list of most recently opened files setting.
        """

        key = 'Recent/Files'
        default_value = QtCore.QVariant([])
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.StringList):
            return setting_value
        else:
            return default_value


    def sessionFiles(self):
        """
        Returns the list of files and nodes opened when the last session quit.
        """

        key = 'Session/Files'
        default_value = QtCore.QVariant([])
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.StringList):
            return setting_value
        else:
            return default_value


    def helpHistory(self):
        """
        Returns the navigation history of the HelpBrowser.
        """

        key = 'HelpBrowser/History'
        default_value = QtCore.QVariant([])
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.StringList):
            return setting_value
        else:
            return default_value


    def helpBookmarks(self):
        """
        Returns the bookmarks of the HelpBrowser.
        """

        key = 'HelpBrowser/Bookmarks'
        default_value = QtCore.QVariant([])
        setting_value = self.value(key)
        if setting_value.canConvert(QtCore.QVariant.StringList):
            return setting_value
        else:
            return default_value


    def writeValue(self, key, value):
        """
        Write an entry to the configuration file.

        :Parameters:

        - `key`: the name of the property we want to set.
        - `value`: the value we want to assign to the property
        """

        try:
            self.setValue(key, QtCore.QVariant(value))
            if self.status():
                raise configException.ConfigFileIOException, \
                    '%s=%s' % (key, value)
        except configException.ConfigFileIOException, inst:
            print inst.error_message

"""
Unit tests for nested record arrays
===================================

:Author:   Ivan Vilata i Balaguer
:Contact:  ivan@selidor.net
:Created:  2007-01-12
:License:  BSD
:Revision: $Id: __init__.py 3698 2008-09-09 12:54:51Z faltet $
"""

<?php

require "example.php";

?>

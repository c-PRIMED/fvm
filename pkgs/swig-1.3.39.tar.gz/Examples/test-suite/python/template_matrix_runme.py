from template_matrix import  *
passVector([1,2,3])
passMatrix([[1,2],[1,2,3]])
passCube([[[1,2],[1,2,3]],[[1,2],[1,2,3]]])




import _enums

_enums.bar2(1)
_enums.bar3(1)
_enums.bar1(1)


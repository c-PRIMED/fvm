from import_nomodule import *

f = create_Foo()
test1(f,42)
delete_Foo(f)

b = Bar()
test1(b,37)

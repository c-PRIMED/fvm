def times_two(a):
    """
    >>> times_two(2)
    4
    >>> times_two('bee')
    beebee
    """
    return a * 2

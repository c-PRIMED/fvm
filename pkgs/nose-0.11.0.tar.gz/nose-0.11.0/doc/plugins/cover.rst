Cover: code coverage
====================

.. autoplugin :: nose.plugins.cover

numpy.ma.MaskedArray.__imod__
=============================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.__imod__

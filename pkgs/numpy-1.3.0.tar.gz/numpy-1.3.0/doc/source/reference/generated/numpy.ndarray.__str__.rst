numpy.ndarray.__str__
=====================

.. currentmodule:: numpy

.. automethod:: ndarray.__str__

numpy.core.defchararray.array
=============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: array

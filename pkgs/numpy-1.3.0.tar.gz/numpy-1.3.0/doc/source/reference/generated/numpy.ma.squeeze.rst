numpy.ma.squeeze
================

.. currentmodule:: numpy.ma

.. autofunction:: squeeze

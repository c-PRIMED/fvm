numpy.ufunc.nargs
=================

.. currentmodule:: numpy

.. autoattribute:: ufunc.nargs

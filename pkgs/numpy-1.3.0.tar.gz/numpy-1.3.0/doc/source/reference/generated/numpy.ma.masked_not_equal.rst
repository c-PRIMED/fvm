numpy.ma.masked_not_equal
=========================

.. currentmodule:: numpy.ma

.. autofunction:: masked_not_equal

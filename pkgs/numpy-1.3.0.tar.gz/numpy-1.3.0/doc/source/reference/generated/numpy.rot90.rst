numpy.rot90
===========

.. currentmodule:: numpy

.. autofunction:: rot90

numpy.ma.MaskedArray.__repr__
=============================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.__repr__

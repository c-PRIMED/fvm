numpy.ma.argsort
================

.. currentmodule:: numpy.ma

.. autofunction:: argsort

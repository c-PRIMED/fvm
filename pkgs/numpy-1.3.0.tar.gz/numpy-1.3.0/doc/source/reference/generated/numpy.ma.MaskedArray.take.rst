numpy.ma.MaskedArray.take
=========================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.take

numpy.cos
=========

.. currentmodule:: numpy

.. autofunction:: cos

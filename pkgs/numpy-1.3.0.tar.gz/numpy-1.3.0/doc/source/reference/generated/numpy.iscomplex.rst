numpy.iscomplex
===============

.. currentmodule:: numpy

.. autofunction:: iscomplex

numpy.ma.average
================

.. currentmodule:: numpy.ma

.. autofunction:: average

numpy.ndarray.__getitem__
=========================

.. currentmodule:: numpy

.. automethod:: ndarray.__getitem__

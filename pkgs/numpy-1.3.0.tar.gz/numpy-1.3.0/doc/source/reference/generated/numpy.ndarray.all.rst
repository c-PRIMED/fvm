numpy.ndarray.all
=================

.. currentmodule:: numpy

.. automethod:: ndarray.all

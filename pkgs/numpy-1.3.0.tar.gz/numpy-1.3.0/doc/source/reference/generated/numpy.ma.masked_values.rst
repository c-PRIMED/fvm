numpy.ma.masked_values
======================

.. currentmodule:: numpy.ma

.. autofunction:: masked_values

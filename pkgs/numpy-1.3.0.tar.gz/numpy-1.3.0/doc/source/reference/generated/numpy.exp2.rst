numpy.exp2
==========

.. currentmodule:: numpy

.. autofunction:: exp2

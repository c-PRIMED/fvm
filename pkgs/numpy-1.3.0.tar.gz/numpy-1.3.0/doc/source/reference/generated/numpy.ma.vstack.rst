numpy.ma.vstack
===============

.. currentmodule:: numpy.ma

.. autofunction:: vstack

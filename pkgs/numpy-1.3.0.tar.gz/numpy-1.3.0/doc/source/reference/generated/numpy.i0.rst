numpy.i0
========

.. currentmodule:: numpy

.. autofunction:: i0

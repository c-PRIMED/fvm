numpy.ma.nonzero
================

.. currentmodule:: numpy.ma

.. autofunction:: nonzero

numpy.ma.MaskedArray.argmax
===========================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.argmax

numpy.distutils.misc_util.yellow_text
=====================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: yellow_text

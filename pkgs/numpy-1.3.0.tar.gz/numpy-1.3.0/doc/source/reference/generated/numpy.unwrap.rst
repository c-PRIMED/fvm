numpy.unwrap
============

.. currentmodule:: numpy

.. autofunction:: unwrap

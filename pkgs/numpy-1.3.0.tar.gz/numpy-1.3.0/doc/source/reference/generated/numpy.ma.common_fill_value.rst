numpy.ma.common_fill_value
==========================

.. currentmodule:: numpy.ma

.. autofunction:: common_fill_value

numpy.ndarray.sort
==================

.. currentmodule:: numpy

.. automethod:: ndarray.sort

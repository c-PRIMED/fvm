numpy.polyval
=============

.. currentmodule:: numpy

.. autofunction:: polyval

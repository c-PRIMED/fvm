numpy.ndarray.__floordiv__
==========================

.. currentmodule:: numpy

.. automethod:: ndarray.__floordiv__

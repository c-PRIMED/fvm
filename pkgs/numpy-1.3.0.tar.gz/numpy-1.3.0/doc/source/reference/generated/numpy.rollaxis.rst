numpy.rollaxis
==============

.. currentmodule:: numpy

.. autofunction:: rollaxis

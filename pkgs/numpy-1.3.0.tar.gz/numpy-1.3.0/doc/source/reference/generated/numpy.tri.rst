numpy.tri
=========

.. currentmodule:: numpy

.. autofunction:: tri

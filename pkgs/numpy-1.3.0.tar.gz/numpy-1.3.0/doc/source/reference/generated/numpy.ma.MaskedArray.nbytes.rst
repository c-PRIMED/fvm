numpy.ma.MaskedArray.nbytes
===========================

.. currentmodule:: numpy.ma

.. autoattribute:: MaskedArray.nbytes

numpy.generic.flags
===================

.. currentmodule:: numpy

.. autoattribute:: generic.flags

numpy.fft.rfft2
===============

.. currentmodule:: numpy.fft

.. autofunction:: rfft2

numpy.dtype.fields
==================

.. currentmodule:: numpy

.. autoattribute:: dtype.fields

numpy.polyder
=============

.. currentmodule:: numpy

.. autofunction:: polyder

numpy.ma.MaskedArray.compress
=============================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.compress

numpy.vstack
============

.. currentmodule:: numpy

.. autofunction:: vstack

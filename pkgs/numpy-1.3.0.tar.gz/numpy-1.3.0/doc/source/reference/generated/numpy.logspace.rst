numpy.logspace
==============

.. currentmodule:: numpy

.. autofunction:: logspace

numpy.ma.getmask
================

.. currentmodule:: numpy.ma

.. autofunction:: getmask

numpy.random.lognormal
======================

.. currentmodule:: numpy.random

.. autofunction:: lognormal

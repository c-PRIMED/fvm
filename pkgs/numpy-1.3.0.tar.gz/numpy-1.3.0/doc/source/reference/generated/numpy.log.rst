numpy.log
=========

.. currentmodule:: numpy

.. autofunction:: log

numpy.ma.MaskedArray.compressed
===============================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.compressed

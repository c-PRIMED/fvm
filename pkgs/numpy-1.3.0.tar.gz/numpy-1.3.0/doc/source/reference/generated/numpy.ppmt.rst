numpy.ppmt
==========

.. currentmodule:: numpy

.. autofunction:: ppmt

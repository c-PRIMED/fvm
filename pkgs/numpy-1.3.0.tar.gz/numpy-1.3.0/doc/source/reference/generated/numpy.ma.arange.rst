numpy.ma.arange
===============

.. currentmodule:: numpy.ma

.. autofunction:: arange

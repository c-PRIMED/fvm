numpy.ndarray.tostring
======================

.. currentmodule:: numpy

.. automethod:: ndarray.tostring

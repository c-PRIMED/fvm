numpy.ndarray.__float__
=======================

.. currentmodule:: numpy

.. automethod:: ndarray.__float__

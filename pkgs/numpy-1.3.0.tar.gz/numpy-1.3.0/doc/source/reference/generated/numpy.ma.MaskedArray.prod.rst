numpy.ma.MaskedArray.prod
=========================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.prod

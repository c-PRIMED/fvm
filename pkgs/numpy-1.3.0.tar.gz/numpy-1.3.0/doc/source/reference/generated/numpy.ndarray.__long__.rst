numpy.ndarray.__long__
======================

.. currentmodule:: numpy

.. automethod:: ndarray.__long__

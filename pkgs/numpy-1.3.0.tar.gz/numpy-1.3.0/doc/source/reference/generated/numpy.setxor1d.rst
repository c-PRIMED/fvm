numpy.setxor1d
==============

.. currentmodule:: numpy

.. autofunction:: setxor1d

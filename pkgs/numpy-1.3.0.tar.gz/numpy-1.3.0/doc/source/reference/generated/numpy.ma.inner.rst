numpy.ma.inner
==============

.. currentmodule:: numpy.ma

.. autofunction:: inner

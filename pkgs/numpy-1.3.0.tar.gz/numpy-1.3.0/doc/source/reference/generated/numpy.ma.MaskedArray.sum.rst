numpy.ma.MaskedArray.sum
========================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.sum

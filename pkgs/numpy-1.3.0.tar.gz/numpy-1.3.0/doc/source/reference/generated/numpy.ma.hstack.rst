numpy.ma.hstack
===============

.. currentmodule:: numpy.ma

.. autofunction:: hstack

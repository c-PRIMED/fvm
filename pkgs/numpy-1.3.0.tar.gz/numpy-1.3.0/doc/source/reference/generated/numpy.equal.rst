numpy.equal
===========

.. currentmodule:: numpy

.. autofunction:: equal

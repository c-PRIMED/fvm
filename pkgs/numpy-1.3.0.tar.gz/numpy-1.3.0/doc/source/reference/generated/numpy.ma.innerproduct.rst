numpy.ma.innerproduct
=====================

.. currentmodule:: numpy.ma

.. autofunction:: innerproduct

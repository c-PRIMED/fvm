numpy.array_equal
=================

.. currentmodule:: numpy

.. autofunction:: array_equal

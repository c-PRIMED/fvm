numpy.ma.MaskedArray.all
========================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.all

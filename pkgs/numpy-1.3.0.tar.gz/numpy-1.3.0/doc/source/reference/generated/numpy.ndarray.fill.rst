numpy.ndarray.fill
==================

.. currentmodule:: numpy

.. automethod:: ndarray.fill

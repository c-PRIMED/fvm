numpy.packbits
==============

.. currentmodule:: numpy

.. autofunction:: packbits

numpy.ma.cumsum
===============

.. currentmodule:: numpy.ma

.. autofunction:: cumsum

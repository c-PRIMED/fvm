numpy.ones
==========

.. currentmodule:: numpy

.. autofunction:: ones

numpy.ma.asanyarray
===================

.. currentmodule:: numpy.ma

.. autofunction:: asanyarray

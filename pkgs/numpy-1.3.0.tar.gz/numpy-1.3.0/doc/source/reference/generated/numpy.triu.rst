numpy.triu
==========

.. currentmodule:: numpy

.. autofunction:: triu

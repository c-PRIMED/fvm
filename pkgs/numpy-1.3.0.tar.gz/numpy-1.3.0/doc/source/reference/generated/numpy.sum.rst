numpy.sum
=========

.. currentmodule:: numpy

.. autofunction:: sum

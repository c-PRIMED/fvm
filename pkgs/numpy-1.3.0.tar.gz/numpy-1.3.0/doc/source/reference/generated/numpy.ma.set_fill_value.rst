numpy.ma.set_fill_value
=======================

.. currentmodule:: numpy.ma

.. autofunction:: set_fill_value

numpy.ndarray.__xor__
=====================

.. currentmodule:: numpy

.. automethod:: ndarray.__xor__

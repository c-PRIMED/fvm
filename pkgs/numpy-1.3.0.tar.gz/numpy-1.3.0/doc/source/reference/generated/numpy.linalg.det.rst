numpy.linalg.det
================

.. currentmodule:: numpy.linalg

.. autofunction:: det

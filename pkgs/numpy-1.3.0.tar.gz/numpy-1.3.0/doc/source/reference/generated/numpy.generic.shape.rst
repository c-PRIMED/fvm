numpy.generic.shape
===================

.. currentmodule:: numpy

.. autoattribute:: generic.shape

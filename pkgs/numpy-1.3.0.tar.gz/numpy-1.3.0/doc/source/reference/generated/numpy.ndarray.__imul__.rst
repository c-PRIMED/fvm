numpy.ndarray.__imul__
======================

.. currentmodule:: numpy

.. automethod:: ndarray.__imul__

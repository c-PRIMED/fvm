numpy.ma.MaskedArray.get_fill_value
===================================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.get_fill_value

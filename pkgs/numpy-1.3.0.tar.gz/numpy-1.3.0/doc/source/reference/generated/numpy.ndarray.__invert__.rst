numpy.ndarray.__invert__
========================

.. currentmodule:: numpy

.. automethod:: ndarray.__invert__

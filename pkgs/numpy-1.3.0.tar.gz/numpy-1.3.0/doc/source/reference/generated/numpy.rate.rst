numpy.rate
==========

.. currentmodule:: numpy

.. autofunction:: rate

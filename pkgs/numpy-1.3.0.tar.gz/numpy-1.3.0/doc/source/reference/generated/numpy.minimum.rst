numpy.minimum
=============

.. currentmodule:: numpy

.. autofunction:: minimum

numpy.ma.transpose
==================

.. currentmodule:: numpy.ma

.. autofunction:: transpose

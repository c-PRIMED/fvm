numpy.argmax
============

.. currentmodule:: numpy

.. autofunction:: argmax

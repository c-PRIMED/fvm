numpy.inner
===========

.. currentmodule:: numpy

.. autofunction:: inner

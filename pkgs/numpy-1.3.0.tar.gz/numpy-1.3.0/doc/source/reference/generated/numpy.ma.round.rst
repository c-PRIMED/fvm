numpy.ma.round
==============

.. currentmodule:: numpy.ma

.. autofunction:: round

numpy.asmatrix
==============

.. currentmodule:: numpy

.. autofunction:: asmatrix

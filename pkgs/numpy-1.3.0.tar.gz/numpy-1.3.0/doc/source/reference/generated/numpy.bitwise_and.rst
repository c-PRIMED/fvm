numpy.bitwise_and
=================

.. currentmodule:: numpy

.. autofunction:: bitwise_and

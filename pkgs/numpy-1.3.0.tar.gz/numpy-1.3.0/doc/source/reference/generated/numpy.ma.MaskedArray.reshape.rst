numpy.ma.MaskedArray.reshape
============================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.reshape

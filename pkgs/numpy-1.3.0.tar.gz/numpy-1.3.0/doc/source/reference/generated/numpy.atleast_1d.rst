numpy.atleast_1d
================

.. currentmodule:: numpy

.. autofunction:: atleast_1d

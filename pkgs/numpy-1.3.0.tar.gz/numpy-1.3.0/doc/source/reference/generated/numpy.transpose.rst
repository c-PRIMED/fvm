numpy.transpose
===============

.. currentmodule:: numpy

.. autofunction:: transpose

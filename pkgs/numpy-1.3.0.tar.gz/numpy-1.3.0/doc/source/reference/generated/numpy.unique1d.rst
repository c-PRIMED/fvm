numpy.unique1d
==============

.. currentmodule:: numpy

.. autofunction:: unique1d

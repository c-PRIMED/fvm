numpy.ndarray.astype
====================

.. currentmodule:: numpy

.. automethod:: ndarray.astype

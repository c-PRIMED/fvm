numpy.piecewise
===============

.. currentmodule:: numpy

.. autofunction:: piecewise

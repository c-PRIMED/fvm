numpy.fft.fftfreq
=================

.. currentmodule:: numpy.fft

.. autofunction:: fftfreq

numpy.intersect1d_nu
====================

.. currentmodule:: numpy

.. autofunction:: intersect1d_nu

numpy.tensordot
===============

.. currentmodule:: numpy

.. autofunction:: tensordot

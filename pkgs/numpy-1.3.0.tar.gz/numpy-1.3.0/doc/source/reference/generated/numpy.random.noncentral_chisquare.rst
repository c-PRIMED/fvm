numpy.random.noncentral_chisquare
=================================

.. currentmodule:: numpy.random

.. autofunction:: noncentral_chisquare

numpy.nonzero
=============

.. currentmodule:: numpy

.. autofunction:: nonzero

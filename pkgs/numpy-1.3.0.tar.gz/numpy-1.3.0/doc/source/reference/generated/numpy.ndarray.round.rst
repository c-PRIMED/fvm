numpy.ndarray.round
===================

.. currentmodule:: numpy

.. automethod:: ndarray.round

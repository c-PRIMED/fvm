numpy.ma.MaskedArray.__rand__
=============================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.__rand__

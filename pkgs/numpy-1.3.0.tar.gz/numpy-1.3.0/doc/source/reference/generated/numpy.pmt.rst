numpy.pmt
=========

.. currentmodule:: numpy

.. autofunction:: pmt

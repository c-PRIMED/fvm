numpy.ndarray.tolist
====================

.. currentmodule:: numpy

.. automethod:: ndarray.tolist

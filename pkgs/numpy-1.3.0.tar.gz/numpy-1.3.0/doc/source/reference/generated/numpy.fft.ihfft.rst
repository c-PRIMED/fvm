numpy.fft.ihfft
===============

.. currentmodule:: numpy.fft

.. autofunction:: ihfft

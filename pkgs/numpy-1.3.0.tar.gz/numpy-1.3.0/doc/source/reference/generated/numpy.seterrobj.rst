numpy.seterrobj
===============

.. currentmodule:: numpy

.. autofunction:: seterrobj

numpy.polyfit
=============

.. currentmodule:: numpy

.. autofunction:: polyfit

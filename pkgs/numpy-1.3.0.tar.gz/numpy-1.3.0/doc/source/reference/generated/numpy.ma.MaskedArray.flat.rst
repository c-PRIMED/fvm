numpy.ma.MaskedArray.flat
=========================

.. currentmodule:: numpy.ma

.. autoattribute:: MaskedArray.flat

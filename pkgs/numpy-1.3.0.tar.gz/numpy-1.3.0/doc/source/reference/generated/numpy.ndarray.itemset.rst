numpy.ndarray.itemset
=====================

.. currentmodule:: numpy

.. automethod:: ndarray.itemset

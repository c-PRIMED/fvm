numpy.ufunc.accumulate
======================

.. currentmodule:: numpy

.. automethod:: ufunc.accumulate

numpy.testing.assert_array_less
===============================

.. currentmodule:: numpy.testing

.. autofunction:: assert_array_less

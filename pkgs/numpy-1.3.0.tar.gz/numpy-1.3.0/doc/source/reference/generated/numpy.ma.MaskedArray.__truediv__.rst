numpy.ma.MaskedArray.__truediv__
================================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.__truediv__

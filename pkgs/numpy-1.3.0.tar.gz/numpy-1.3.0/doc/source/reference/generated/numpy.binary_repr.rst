numpy.binary_repr
=================

.. currentmodule:: numpy

.. autofunction:: binary_repr

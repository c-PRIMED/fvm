numpy.mirr
==========

.. currentmodule:: numpy

.. autofunction:: mirr

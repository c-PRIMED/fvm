numpy.ndarray.flatten
=====================

.. currentmodule:: numpy

.. automethod:: ndarray.flatten

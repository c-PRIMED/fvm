numpy.r_
========

.. currentmodule:: numpy

.. autofunction:: r_

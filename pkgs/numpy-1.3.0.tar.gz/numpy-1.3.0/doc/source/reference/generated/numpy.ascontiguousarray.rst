numpy.ascontiguousarray
=======================

.. currentmodule:: numpy

.. autofunction:: ascontiguousarray

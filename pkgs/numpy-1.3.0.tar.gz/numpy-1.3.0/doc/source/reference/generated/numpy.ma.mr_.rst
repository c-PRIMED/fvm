numpy.ma.mr_
============

.. currentmodule:: numpy.ma

.. autofunction:: mr_

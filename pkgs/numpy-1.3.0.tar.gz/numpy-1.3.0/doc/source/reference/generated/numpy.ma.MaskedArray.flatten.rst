numpy.ma.MaskedArray.flatten
============================

.. currentmodule:: numpy.ma

.. automethod:: MaskedArray.flatten

numpy.flatnonzero
=================

.. currentmodule:: numpy

.. autofunction:: flatnonzero

numpy.ma.all
============

.. currentmodule:: numpy.ma

.. autofunction:: all

numpy.random.bytes
==================

.. currentmodule:: numpy.random

.. autofunction:: bytes

numpy.fft.fftn
==============

.. currentmodule:: numpy.fft

.. autofunction:: fftn

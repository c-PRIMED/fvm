numpy.linalg.solve
==================

.. currentmodule:: numpy.linalg

.. autofunction:: solve

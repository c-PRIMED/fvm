numpy.less
==========

.. currentmodule:: numpy

.. autofunction:: less

numpy.isposinf
==============

.. currentmodule:: numpy

.. autofunction:: isposinf

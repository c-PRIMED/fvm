numpy.ma.make_mask_descr
========================

.. currentmodule:: numpy.ma

.. autofunction:: make_mask_descr

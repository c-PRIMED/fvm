numpy.restoredot
================

.. currentmodule:: numpy

.. autofunction:: restoredot

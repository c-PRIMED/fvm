numpy.c_
========

.. currentmodule:: numpy

.. autofunction:: c_

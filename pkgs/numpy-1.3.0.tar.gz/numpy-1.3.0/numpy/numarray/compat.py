
__all__ = ['NewAxis', 'ArrayType']

from numpy import newaxis as NewAxis, ndarray as ArrayType

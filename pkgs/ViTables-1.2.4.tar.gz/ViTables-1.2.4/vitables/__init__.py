__version__ = '1.2'
__all__ = ["docBrowser","h5db", "nodeProperties", "nodes",
    "preferences", "treeEditor", "vtTables", "vtWidgets",
    "utils", "vtSite", "vtapp", "vtgui", "vtsplash"]

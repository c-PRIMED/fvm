#include "PolyhedralSurf.h"



// Vector_3 PolyhedralSurf::getHalfedge_vector(Halfedge * h)
// {
//   Vector_3 v = h->opposite()->vertex()->point() - h->vertex()->point();
//   return v;
// }

from numexpr.tests.test_numexpr import test, print_versions

if __name__ == '__main__':
    test()

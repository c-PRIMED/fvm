"""
Gaussian processes examples.
"""
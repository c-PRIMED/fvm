"""
Examples for PyMC.
"""
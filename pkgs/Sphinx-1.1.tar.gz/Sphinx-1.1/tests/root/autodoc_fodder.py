
class MarkupError(object):
    """
    .. note:: This is a docstring with a
    small markup error which should have
    correct location information.
    """

print "line 1"
print "line 2"
